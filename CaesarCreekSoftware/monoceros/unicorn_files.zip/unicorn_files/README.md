Setup:
	pip3 install unicorn
	pip3 install capstone

Usage:
	python3 unicorn_harness.py unicorn_context/

This process context dump fell off the back of a truck. Can you use it to help us decode the secret message from the WHO?